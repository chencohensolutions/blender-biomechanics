bl_info = {
    "name": "Biomechanics Simulator",
    "author": "Biomechanics Project",
    "version": (0, 1, 0),
    "blender": (3, 6, 0),
    "location": "3D Viewport > Sidebar > Biomechanics",
    "description": "Tools for simulating biomechanical movement",
    "category": "3D View",
}

import bpy


class BIOMECHANICS_OT_hello_world(bpy.types.Operator):
    """Test the Biomechanics add-on"""

    bl_idname = "biomechanics.hello_world"
    bl_label = "Hello World"
    bl_options = {"REGISTER"}

    def execute(self, context):
        self.report({"INFO"}, "Hello from Biomechanics Simulator!")
        print("Hello from Biomechanics Simulator!")
        return {"FINISHED"}


class BIOMECHANICS_PT_main_panel(bpy.types.Panel):
    bl_label = "Biomechanics Simulator"
    bl_idname = "BIOMECHANICS_PT_main_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Biomechanics"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Bone Movement Tools", icon="ARMATURE_DATA")
        layout.operator(
            BIOMECHANICS_OT_hello_world.bl_idname,
            text="Hello World",
            icon="PLAY",
        )


CLASSES = (
    BIOMECHANICS_OT_hello_world,
    BIOMECHANICS_PT_main_panel,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()